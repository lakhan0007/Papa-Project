import React from 'react'
import Navbar from "../Components/Navbar/Navbar";
import Footer from "../Components/Footer/Footer";
import Contect from '../Components/ContectUs/ContectUs'

function ContectUs() {
  return (
    <>
      <Navbar />
      <Contect/>
      <Footer />
    </>
  );
}

export default ContectUs